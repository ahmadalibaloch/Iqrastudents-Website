<?php
	require('application/config.php');	
	require('framework/App.php');
	set_public_root(__FILE__);	
	
	App::start();