<?php
class Klass extends Model
{
	static $table = 'klasses';
	static $cols = 'id, name';
}