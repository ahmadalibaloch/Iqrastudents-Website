<?php
class Role extends Model
{
	static $table = 'roles';
	static $cols = 'id, name';
}