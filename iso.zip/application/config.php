<?php	
	define('APP_ENV', 'development');
	define('APP_URL', 'http://localhost/iso/');	
	define('DB_HOST', 'localhost');
	define('DB_USER', 'root');
	define('DB_PASS', '');
	define('DB_NAME', 'iso');
	
	define('CONTR_INDEX', 2);
	define('IS_MOBILE', false);
	
	define('APP_ROOT', dirname(__FILE__).DIRECTORY_SEPARATOR);