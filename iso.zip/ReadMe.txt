************** READ ME File ******************

Project DATE uplouded:
 25/05//2012

Project Name:
 Online System of IQRA STUDENT ORGANIZATION

Develope By: Badar Munir Ahmad(08030564)
it is my fyp project, which is credit module
 

To Oprate this website, default username and password is given below


************** UserName/password *****
--for Admin--				"
Username= badar				"
password= 123*				"
					"
					"
--for Teacher--				"
Username= noman				"
password= 123*				"
					"
--for Student--				"
Username= asadullah			"
password= 123*				"

--for member--				"
Username= dost				"
password= 123*				"

*****************************************                 


*************************************************************************************
INSTALLATION NOTES
If you want to install this website on localhost, then you have require 
1. PHPMyAdmin
2. Apache Sever
3. Opera and google Chrome is the best for this software to run on..
Installation of Database
go to php myAdmin->creat new database name "iso"
then import file from the project. Project name is iso and the database name is also iso
*************************************************************************************

